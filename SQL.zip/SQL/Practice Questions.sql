/* Book data*/
-- 1.	Write a query to print the Book count corresponding to each Genre in the dataset.

-- 2.	Write a query to print the Genre of the books that has got the best Revenue (top 5) Increase 
-- from the year 2017 to 2018



-- 3. 	Write a query to print the number of books with non available data for language_code.



-- 4.	Write a query to print the Genre of the books that have got 5 least Revenue in the year 2018.



/* Employee_Detailsemployee_details table*/
-- 5.  Write a query to show the Department & Joining year for Jennice & Daniel.



-- 6. Write a query to show the employee detail where Sr. Leads are earning more than Asst. Managers.



-- 7. Using the HR Schema, Write a Query to print the name and  a message 'Well Paid' or 'Underpaid' if the salary is above or below 6500$ respectively.



-- 8. Write a query in SQL to display the department name, city, and state province for each department.



-- 9. Write a query in SQL to display the job title, department name, full name (first and last name ) of employee, and starting date for all the jobs which started on or after 1st January, 1993 and ending with on or before 31 August, 1997.



-- 10. Write a query to display the employee id, employee name (first name and last name ) 
-- for all employees who earn more than the average salary. (HR schema)

                             
                             
                                
-- 11. Write a query to display the employee name( first name and last name ) and 
-- hiredate for all employees in the same department as Clara. Exclude Clara. (HR schema)



-- 12. Write a query in SQL to display the first and last name, salary, and 
-- department ID for those employees who earn less than the average salary, 
-- and also work at the department where the employee Laura is working as a first name holder. (HR schema)



-- 13. Display 5th highest salary of employee using subquery (HR schema)


        
-- 14. Write a query to display net Salary of employees even if the commission is not given . (HR schema)
 
 
-- 15. Display first_name of the employees who are not receiving any commission and first 
-- name contains 't' (HR schema)


-- 16. Display contactname and phone of customers ,if bizphone is not there homephone should show up."
-- Contacts: Contact name, bizphone
 use hr;



-- 17. Display first_name ,commission and where commission ISNULL print 
-- 'Its Null' otherwise print 'Its not null
 use hr;


 
-- 18. Display system date ,total number of rows from employees and departments table in a single row and 3 columns
 use hr;
 



-- 19. Display the age if the date of birth is '1999-10-12'


 
 -- 20. Display '1' if 2<>0 condition is true otherwise display '0' 


-- 21. Display the user name in mysql

 
 -- 23. Using Classicmodels schema, Write a Query to find the list of customers residing in the same city.
Use Classicmodels;




-- 24. Let us consider the below tables.

-- Products (Product_id, Product_name,Price)
-- Promotions (Promotion id, Promo_name, Promo_desc)

-- Identify the promotions that can be applied to each product.

use bootcamp;



-- 25. A Business consultant wants to draw out organisation structure for a company. 
-- He needs details about the names of the employees and the names of the persons who manage them. 
-- If the person is at the highest position then he will not have a manager , 
-- in such cases the code "Top Management Employee" must be displayed in the result set. 
-- Write a Query for the same.
Use hr;




-- ----------------------------------- Window Functions ----------------------------------------------------

-- 26. Fetch the employee id's of each department, their name, department id and 
-- the number of employees in each department, 
-- include only department id 80 and those commission percentage is more than 30% 

Use hr;



-- 27. Fetch the employee id's , their name, manager id, salary, average salary
-- of employees reporting under each manager and the difference between them
Use hr;



-- 28. Fetch the employee id's , their name, job id, salary, total salary of employees job id level, 
-- and the proportion of their salary to their total salary in each job id
Use hr;



-- 29. For each employee, fetch the employee id, department id, job id, start_date and their UNIQUE rank (use row number() consider start_date)
-- sort by start date and then by hire date both in descending order.
Use hr;


-- 30. For For each employee, fetch the employee id, department id, job id, their rank (without skip levels) by commission_pct. 
-- Order the employees details by hire_date with recent hire_date coming first.
Use hr;



-- 31. Divide the employees into 10 groups with highest paid employees coming first.
-- For each employee fetch the emp id, department id salary and the group they belong to
Use hr;



-- 24. For each employee, fetch the emp id, department id salary  and sum of salary up to the current
-- hire_date when sorted by the hired date.
Use hr;



-- 32. For employees in department 50,  fetch the emp id, department id salary  and the sum of salary of the 
-- remaining employees in the department (include the current row) when the hire date is sorted in ascending order 
Use hr;


-- 33. Fetch the order date, order id, product id, product quantity ordered on each day and the total sum of products
-- ordered on each day
Use hr;



-- 34. Fetch the order date, order id, product id, product quantity ordered on each day and the total sum of products
-- calculated by taking 1 previous product quantity, the current product quantity and 1 following product quantity 
-- (in terms of the order date) and the ratio of the product qunatity to the total product qunatity calculated as before.
Use hr;


-- 35. Fetch the order date, order id, product id, product quantity and Quantity ordered in a single day for each row
Use hr;


-- 36. Using HR Schema, Write a Query to find the first day of first job of every employee.
Use hr;

-- 30. Using classicmodels Schema, Write a Query to  fetch the name of the customer along with 
-- the current and previous order date.
Use classicmodels;



-- 37. Using classicmodels Schema, Write a Query to  fetch the name of the product line 
-- with sales for every Year  along with sales from the Previous year.

Use classicmodels;

-- 38. Write a query to find out one Excellent employee, one moderate performing employee, 
-- one average performing employee and one poor performing employee from the entire office.
-- By Excellent performance we mean the rating should be in the 4th quartile,
-- by Moderate performance we mean the rating should be in the 3rd quartile, 
-- by Average performance we mean the rating should be in the 2nd quartile and 
-- by Poor performance we mean the rating should be in the 1st quartile


-- ----------------------------------------------------------------------------------------------------------------
-- 39. Pivot table in mysql for the number of orders delivered by each shipper to customer


-- --------------------------------------------------------------------------------------------------

-- 40. From the past 10 months, find the sessions which lasted for more than a minute. 

